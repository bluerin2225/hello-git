#include <stdio.h>
#include <memory.h>

typedef union {
	float f;
	double d;
	long double ld;
	unsigned char c[8];
	int i;
	long l;
	long long ll;
} test_un;

float MakeFloat(int sign, int exp, int fraction)
{
	test_un t;
	memset(&t, 0, sizeof(t));

	t.i = (exp << 23) | (fraction & 0x007FFFFF);
	if (sign != 0)
		t.i |= 0x80000000;

	return t.f;
}

int main()
{
	test_un t;
	memset(&t, 0, sizeof(t));
	/*t.i = 0x12345678;*/
	/*
	printf("sizeof(float): %d\n", sizeof(float));
	printf("sizeof(double): %d\n", sizeof(double));
	printf("sizeof(long double): %d\n", sizeof(long double));
	printf("sizeof(int): %d\n", sizeof(int));
	printf("sizeof(long): %d\n", sizeof(long));
	printf("sizeof(long long): %d\n", sizeof(long long));
	*/

	/*
		0-000 0000 0-000 0000 0000 0000 0000 0000 
		
		(10)d -> (1010)b -> (1.010)b x 2<3> -> (1.010)b x 2<130-127>
		130 = 82h = 10000010b
		0-100 0001 0-010 0000 0000 0000 0000 0000
	*/
	printf("MakeFloat = %f\n", MakeFloat(0, 130, 0x00200000));

	printf("=== zero ====\n");
	printf("%f\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	printf("=== 10 ====\n");
	t.c[0] = 0x00;
	t.c[1] = 0x00; 
	t.c[2] = 0x20; 
	t.c[3] = 0x41;
	printf("%f\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	/*
		0 - 000 0000 0 - 000 0000 0000 0000 0000 0000
		0 - 111 1111 1 - 000 0000 0000 0000 0000 0000
	*/
	printf("=== max exp / zero fraction ====\n");
	t.c[0] = 0x00;
	t.c[1] = 0x00;
	t.c[2] = 0x80;
	t.c[3] = 0x7F;
	printf("%f\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	/*
		0 - 000 0000 0 - 000 0000 0000 0000 0000 0000
		0 - 000 0000 0 - 111 1111 1111 1111 1111 1111
	*/
	printf("=== zero exp / max fraction ====\n");
	t.c[0] = 0xFF;
	t.c[1] = 0xFF;
	t.c[2] = 0x7F;
	t.c[3] = 0x00;
	printf("%f\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	/*
		0 - 000 0000 0 - 000 0000 0000 0000 0000 0000
		0 - 111 1111 0 - 000 0000 0000 0000 0000 0000
	*/
	printf("=== max exp - 1 / zero fraction ====\n");
	t.c[0] = 0x00;
	t.c[1] = 0x00;
	t.c[2] = 0x00;
	t.c[3] = 0x7F;
	printf("%f\n", t.f);
	printf("%e\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	/*
		0 - 000 0000 0 - 000 0000 0000 0000 0000 0000
		0 - 111 1111 0 - 111 1111 1111 1111 1111 1111
	*/
	printf("=== max exp - 1 / max fraction (positive) ====\n");
	t.c[0] = 0xFF;
	t.c[1] = 0xFF;
	t.c[2] = 0x7F;
	t.c[3] = 0x7F;
	printf("%f\n", t.f);
	printf("%e\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	/*
		0 - 000 0000 0 - 000 0000 0000 0000 0000 0000
		1 - 111 1111 0 - 111 1111 1111 1111 1111 1111
	*/
	printf("=== max exp - 1 / max fraction (negative) ====\n");
	t.c[0] = 0xFF;
	t.c[1] = 0xFF;
	t.c[2] = 0x7F;
	t.c[3] = 0xFF;
	printf("%f\n", t.f);
	printf("%e\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	/*
		0 - 000 0000 0 - 000 0000 0000 0000 0000 0000
		0 - 000 0000 0 - 111 1111 1111 1111 1111 1111
	*/
	printf("=== zero exp / max fraction (positive) ====\n");
	t.c[0] = 0xFF;
	t.c[1] = 0xFF;
	t.c[2] = 0x7F;
	t.c[3] = 0x00;
	printf("%f\n", t.f);
	printf("%e\n", t.f);
	printf("%02X-%02X-%02X-%02X-\n", t.c[0], t.c[1], t.c[2], t.c[3]);

	/*
			����	- �w����		- ������
			0		- 000 0000 0	- 000 0000 0000 0000 0000 0000
			1		- 0				- 0

			0		- 0				- 1
			0		- 0				- 2
			0		- 0				- MAX-1
			0		- 0				- MAX
			1		- 0				- 1
			1		- 0				- 2
			1		- 0				- MAX-1
			1		- 0				- MAX

			0		- 1				- 0
			0		- 2				- 0
			0		- MAX-1			- 0
			0		- MAX			- 0
			1		- 1				- 0
			1		- 2				- 0
			1		- MAX-1			- 0
			1		- MAX			- 0
		*/
	printf("=====\n");
	printf("MakeFloat = %f\n", MakeFloat(0, 0, 0x00000000));
	printf("-----\n");
	printf("MakeFloat = %f\n", MakeFloat(1, 0, 0x00000000));
	printf("=====\n");
	printf("MakeFloat = %f\n", MakeFloat(0, 0, 1));
	printf("MakeFloat = %f\n", MakeFloat(0, 0, 2));
	printf("MakeFloat = %f\n", MakeFloat(0, 0, 0x7FFFFF - 1));
	printf("MakeFloat = %f\n", MakeFloat(0, 0, 0x7FFFFF));
	printf("-----\n");
	printf("MakeFloat = %f\n", MakeFloat(1, 0, 1));
	printf("MakeFloat = %f\n", MakeFloat(1, 0, 2));
	printf("MakeFloat = %f\n", MakeFloat(1, 0, 0x7FFFFF - 1));
	printf("MakeFloat = %f\n", MakeFloat(1, 0, 0x7FFFFF));
	printf("=====\n");
	printf("MakeFloat = %f\n", MakeFloat(0, 1, 0));
	printf("MakeFloat = %f\n", MakeFloat(0, 2, 0));
	printf("MakeFloat = %f\n", MakeFloat(0, 0xFF - 1, 0));
	printf("MakeFloat = %f\n", MakeFloat(0, 0xFF, 0));
	printf("-----\n");
	printf("MakeFloat = %f\n", MakeFloat(1, 1, 0));
	printf("MakeFloat = %f\n", MakeFloat(1, 2, 0));
	printf("MakeFloat = %f\n", MakeFloat(1, 0xFF - 1, 0));
	printf("MakeFloat = %f\n", MakeFloat(1, 0xFF, 0));

	return 0;
}