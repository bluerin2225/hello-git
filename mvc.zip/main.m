function main()
mymodel = model();
mycontroller = controller(mymodel);